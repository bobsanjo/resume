(function() {
var toc =  [{"type":"item","name":"Export","url":"Ncore_3_Online_Documentation/User_Guide/Export/Export.htm"},{"type":"item","name":"Export a Design","url":"Ncore_3_Online_Documentation/User_Guide/Export/Export_a_Design.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
(function() {
var toc =  [{"type":"item","name":"Protocols and Interfaces","url":"Ncore_3_Online_Documentation/Reference_Guide/Protocols_and_Interfaces/Protocols_and_Interfaces.htm"},{"type":"item","name":"Cache Coherency Protocol","url":"Ncore_3_Online_Documentation/Reference_Guide/Protocols_and_Interfaces/Cache_Coherency_Protocol.htm"},{"type":"item","name":"Supported Protocols","url":"Ncore_3_Online_Documentation/Reference_Guide/Protocols_and_Interfaces/Supported_Protocols.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
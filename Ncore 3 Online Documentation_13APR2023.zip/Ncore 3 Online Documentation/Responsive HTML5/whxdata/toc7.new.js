(function() {
var toc =  [{"type":"item","name":"EmbedMem","url":"Ncore_3_Online_Documentation/Integration_Guide/EmbedMem/EmbedMem.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
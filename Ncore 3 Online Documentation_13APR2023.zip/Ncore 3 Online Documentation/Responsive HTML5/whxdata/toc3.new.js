(function() {
var toc =  [{"type":"item","name":"Flex Licensing Manager","url":"Ncore_3_Online_Documentation/Get_Started/Flex_Licensing_Manager/Flex_Licensing_Manager.htm"},{"type":"item","name":"Maestro Licensing","url":"Ncore_3_Online_Documentation/Get_Started/Flex_Licensing_Manager/Maestro_Licensing.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
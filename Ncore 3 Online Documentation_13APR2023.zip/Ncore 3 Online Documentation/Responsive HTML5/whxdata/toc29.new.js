(function() {
var toc =  [{"type":"item","name":"SysSoftwareGuide","url":"Ncore_3_Online_Documentation/Reference_Guide/SysSoftwareGuide/SysSoftwareGuide.htm"},{"type":"item","name":"Reset and Initialization","url":"Ncore_3_Online_Documentation/Reference_Guide/SysSoftwareGuide/Reset_and_Initialization.htm"},{"type":"item","name":"Q channel clock gating sequence","url":"Ncore_3_Online_Documentation/Reference_Guide/SysSoftwareGuide/Q_channel_clock_gating_sequence.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
(function() {
var toc =  [{"type":"book","name":"Intro","key":"toc5"},{"type":"book","name":"ExtTimingReq","key":"toc6"},{"type":"book","name":"EmbedMem","key":"toc7"},{"type":"book","name":"ResiliencyIntegration","key":"toc8"},{"type":"book","name":"IP_XACT","key":"toc9"},{"type":"book","name":"LogicSynthesis","key":"toc10"},{"type":"book","name":"Simulation","key":"toc11"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
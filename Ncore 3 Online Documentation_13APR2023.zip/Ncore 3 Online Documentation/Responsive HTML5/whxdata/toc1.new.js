(function() {
var toc =  [{"type":"book","name":"Getting Started","key":"toc2"},{"type":"book","name":"Flex Licensing Manager","key":"toc3"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
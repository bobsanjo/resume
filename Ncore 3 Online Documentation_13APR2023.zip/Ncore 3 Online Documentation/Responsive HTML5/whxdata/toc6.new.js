(function() {
var toc =  [{"type":"item","name":"ExtTimingReq","url":"Ncore_3_Online_Documentation/Integration_Guide/ExtTimingReq/ExtTimingReq.htm"},{"type":"item","name":"Integrating Synchronous Interfaces","url":"Ncore_3_Online_Documentation/Integration_Guide/ExtTimingReq/Integrating_Synchronous_Interfaces.htm"},{"type":"item","name":"Integrating Asynchronous Interfaces","url":"Ncore_3_Online_Documentation/Integration_Guide/ExtTimingReq/Integrating_Asynchronous_Interfaces.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"Active State","last":"SNP","num":"84","node":"gdata1"},{"type":"chunkinfo","first":"SoC","last":"Write Transaction Table","num":"13","node":"gdata2"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
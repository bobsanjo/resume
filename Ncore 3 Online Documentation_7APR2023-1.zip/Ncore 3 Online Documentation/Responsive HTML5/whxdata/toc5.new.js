(function() {
var toc =  [{"type":"item","name":"Intro","url":"Ncore_3_Online_Documentation/Integration_Guide/Intro/Intro.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
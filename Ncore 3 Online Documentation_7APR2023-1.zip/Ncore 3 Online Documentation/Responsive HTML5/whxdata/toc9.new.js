(function() {
var toc =  [{"type":"item","name":"IP_XACT","url":"Ncore_3_Online_Documentation/Integration_Guide/IP_XACT/IP_XACT.htm"},{"type":"item","name":"IP-XACT Configuration","url":"Ncore_3_Online_Documentation/Integration_Guide/IP_XACT/IP-XACT_Configuration.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
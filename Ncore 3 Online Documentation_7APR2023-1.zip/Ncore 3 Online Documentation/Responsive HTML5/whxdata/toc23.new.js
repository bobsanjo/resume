(function() {
var toc =  [{"type":"item","name":"Glossary","url":"Ncore_3_Online_Documentation/User_Guide/Glossary/Glossary.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
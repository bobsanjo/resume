(function() {
var toc =  [{"type":"item","name":"Ncore 3 Introduction","url":"Ncore_3_Online_Documentation/Reference_Guide/Ncore_3_Introduction/Ncore_3_Introduction.htm"},{"type":"item","name":"System Overview","url":"Ncore_3_Online_Documentation/Reference_Guide/Ncore_3_Introduction/System_Overview.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
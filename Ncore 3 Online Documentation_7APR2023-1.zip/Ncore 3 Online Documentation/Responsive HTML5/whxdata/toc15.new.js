(function() {
var toc =  [{"type":"item","name":"SOC Specification","url":"Ncore_3_Online_Documentation/User_Guide/SOC_Specification/SOC_Specification.htm"},{"type":"item","name":"SoC Specification Overview","url":"Ncore_3_Online_Documentation/User_Guide/SOC_Specification/SoC_Specification_Overview.htm"},{"type":"item","name":"Create a System and a Subsystem","url":"Ncore_3_Online_Documentation/User_Guide/SOC_Specification/Create_a_System_and_a_Subsystem.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
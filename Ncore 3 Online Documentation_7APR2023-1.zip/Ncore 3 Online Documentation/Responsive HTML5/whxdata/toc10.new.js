(function() {
var toc =  [{"type":"item","name":"LogicSynthesis","url":"Ncore_3_Online_Documentation/Integration_Guide/LogicSynthesis/LogicSynthesis.htm"},{"type":"item","name":"Synthesis Script Files","url":"Ncore_3_Online_Documentation/Integration_Guide/LogicSynthesis/Synthesis_Script_Files.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
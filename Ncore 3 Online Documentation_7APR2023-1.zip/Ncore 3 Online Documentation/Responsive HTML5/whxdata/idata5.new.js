(function() {
var index =  {"type":"data","keys":[{"type":"key","name":"Width Adapters","topics":[{"type":"topic","name":"Transport Interconnect","url":"Ncore_3_Online_Documentation/Reference_Guide/System_Attributes/Transport_Interconnect.htm#IX_Width_Adapters"}]},{"type":"key","name":"Window Menu","topics":[{"type":"topic","name":"Maestro Menus and Shortcuts","url":"Ncore_3_Online_Documentation/User_Guide/Graphical_User_Interface/Maestro_Menus_and_Shortcuts.htm#IX_Window_Menu"}]}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
(function() {
var toc =  [{"type":"item","name":"Resiliency","url":"Ncore_3_Online_Documentation/Reference_Guide/Resiliency/Resiliency.htm"},{"type":"item","name":"Functional Safety Overview","url":"Ncore_3_Online_Documentation/Reference_Guide/Resiliency/Functional_Safety_Overview.htm"},{"type":"item","name":"Functional Safety Elements Description","url":"Ncore_3_Online_Documentation/Reference_Guide/Resiliency/Functional_Safety_Elements_Description.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();